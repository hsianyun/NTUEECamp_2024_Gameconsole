---
name: Device support request (デバイスサポート要望)
about: MCU / LCD / OLED / EPD / etc... device support request
title: ''
labels: device support request
assignees: ''

---

**Carefully written requests are more likely to be given priority.**
**丁寧に記述された要望は優先して対応される可能性が高くなります。**

### Device Name (デバイスの名称・型番等)

### URL of Device Specifications document (仕様書等のURL)

### URL of the store where we can purchase (商品を購入できるURL)
